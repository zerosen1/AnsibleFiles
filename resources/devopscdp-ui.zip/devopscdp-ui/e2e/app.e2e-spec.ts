import { DevopsdashboardPage } from './app.po';

describe('devopsdashboard App', () => {
  let page: DevopsdashboardPage;

  beforeEach(() => {
    page = new DevopsdashboardPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
