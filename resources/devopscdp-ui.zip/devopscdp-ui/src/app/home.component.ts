import { Component, OnInit } from '@angular/core';
 
import { User } from './models/user';
import { ProjectService } from './services/index';
 
@Component({
    moduleId: module.id,
    templateUrl: 'home.component.html'
})
 
export class HomeComponent implements OnInit {
    currentUser: User;
    model: any ;
 
    constructor(private ProjectService: ProjectService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.model={};
        this.model.projectWidgets=[];
    }
 
    ngOnInit() {
        this.loadProjectDashboard();
    }
 
    private loadProjectDashboard() {
        this.ProjectService.getProjectHome().subscribe(model => { this.model = model; });
    }
}