import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { AlertService, AuthenticationService } from './services/index';

@Component({
    moduleId: module.id,
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    model: any = {};
    loading = false;
    error: string;
    returnUrl: string;
    token: string;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService) { }

    ngOnInit() {
        // reset login status
        this.authenticationService.logout();
        // set token if saved in local storage
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.token = currentUser && currentUser.token;
        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    login() {
        this.loading = true;
        this.authenticationService.login(this.model.username, this.model.password)
            .subscribe(
            (response) => {

                // login successful if there's a jwt token in the response
                //let token = response.json() && response.json().token;


                if (response.status ===200) {
                    // set token property
                    let _token = this.extractDataAndSetAuthHeader(this.model.username, response);
                    this.token = _token;
                    this.router.navigateByUrl(this.returnUrl);

                } else {
                    // return false to indicate failed login
                    this.alertService.error(JSON.stringify(response));
                this.loading = false;
                this.error = response.status.toString() + " : " + response.statusText;
                }
            },
            (error) => {
                // login failed so display error
                this.alertService.error(error);
                this.error = error.statusText;
                this.loading = false;
            });
    }


    private extractDataAndSetAuthHeader(username: string, res: Response) {

        // Set auth header if available.
        // If not available - user is not logged in. Then 
        // we also have to remove the token from localStorage
        if (res.headers.has("authorization")) {
            let token = res.headers.get("authorization");
            this.setToken(username, token);
            console.log('I took out the auth header: ' + token);
            return token;
        }
        else {
            // If no token is sent, remove it
            this.removeToken(username);
            return null;
        }

    }

    private setToken(username: string, token: string) {
        this.token = token;
        // store username and jwt token in local storage to keep user logged in between page refreshes
        localStorage.setItem('currentUser', JSON.stringify({ username: username, token: token }));
    }

    private removeToken(username) {
        localStorage.removeItem('currentUser');
    }



}